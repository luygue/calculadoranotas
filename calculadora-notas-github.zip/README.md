# Calculadora de Notas da Faculdade

Calculadora simples em HTML, CSS e JavaScript para calcular:

- N2 = (Parcial N2 + Institucional N2) / 2
- Média Final = (N1 + N2) / 2
- Aprovação com média igual ou maior que 6

## Como publicar no GitHub Pages

1. Crie um repositório no GitHub.
2. Envie o arquivo `index.html` para a raiz do repositório.
3. Vá em Settings > Pages.
4. Em Source, escolha Deploy from a branch.
5. Em Branch, escolha `main` e `/root`.
6. Salve e aguarde o link do GitHub Pages aparecer.
